﻿Console.WriteLine("             |----M-M----|");
Console.WriteLine("             | 3.feladat |");
Console.WriteLine("             |---12-06---|");

Console.ReadKey();