﻿Console.WriteLine("             |----M-M----|");
Console.WriteLine("             | Try-catch |");
Console.WriteLine("             |---12-06---|");

Console.ReadKey();