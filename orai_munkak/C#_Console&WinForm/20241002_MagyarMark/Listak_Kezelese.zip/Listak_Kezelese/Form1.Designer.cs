﻿namespace Listak_Kezelese
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lBA = new System.Windows.Forms.ListBox();
            this.LblA = new System.Windows.Forms.Label();
            this.LBLB = new System.Windows.Forms.Label();
            this.lBB = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lBMetszet = new System.Windows.Forms.ListBox();
            this.btn_keszit = new System.Windows.Forms.Button();
            this.btn_szamol = new System.Windows.Forms.Button();
            this.lBUnio = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lBA
            // 
            this.lBA.FormattingEnabled = true;
            this.lBA.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.lBA.Location = new System.Drawing.Point(53, 50);
            this.lBA.Name = "lBA";
            this.lBA.Size = new System.Drawing.Size(47, 277);
            this.lBA.TabIndex = 0;
            // 
            // LblA
            // 
            this.LblA.AutoSize = true;
            this.LblA.Location = new System.Drawing.Point(50, 34);
            this.LblA.Name = "LblA";
            this.LblA.Size = new System.Drawing.Size(50, 13);
            this.LblA.TabIndex = 1;
            this.LblA.Text = "A halmaz";
            // 
            // LBLB
            // 
            this.LBLB.AutoSize = true;
            this.LBLB.Location = new System.Drawing.Point(142, 34);
            this.LBLB.Name = "LBLB";
            this.LBLB.Size = new System.Drawing.Size(50, 13);
            this.LBLB.TabIndex = 3;
            this.LBLB.Text = "B halmaz";
            // 
            // lBB
            // 
            this.lBB.FormattingEnabled = true;
            this.lBB.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.lBB.Location = new System.Drawing.Point(145, 50);
            this.lBB.Name = "lBB";
            this.lBB.Size = new System.Drawing.Size(47, 277);
            this.lBB.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(235, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "A metszet B";
            // 
            // lBMetszet
            // 
            this.lBMetszet.FormattingEnabled = true;
            this.lBMetszet.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.lBMetszet.Location = new System.Drawing.Point(238, 50);
            this.lBMetszet.Name = "lBMetszet";
            this.lBMetszet.Size = new System.Drawing.Size(47, 277);
            this.lBMetszet.TabIndex = 4;
            // 
            // btn_keszit
            // 
            this.btn_keszit.Location = new System.Drawing.Point(43, 347);
            this.btn_keszit.Name = "btn_keszit";
            this.btn_keszit.Size = new System.Drawing.Size(139, 23);
            this.btn_keszit.TabIndex = 6;
            this.btn_keszit.Text = "Készít";
            this.btn_keszit.UseVisualStyleBackColor = true;
            this.btn_keszit.Click += new System.EventHandler(this.btn_keszit_Click);
            // 
            // btn_szamol
            // 
            this.btn_szamol.Location = new System.Drawing.Point(198, 347);
            this.btn_szamol.Name = "btn_szamol";
            this.btn_szamol.Size = new System.Drawing.Size(139, 23);
            this.btn_szamol.TabIndex = 7;
            this.btn_szamol.Text = "Számol";
            this.btn_szamol.UseVisualStyleBackColor = true;
            this.btn_szamol.Click += new System.EventHandler(this.btn_szamol_Click);
            // 
            // lBUnio
            // 
            this.lBUnio.FormattingEnabled = true;
            this.lBUnio.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.lBUnio.Location = new System.Drawing.Point(320, 50);
            this.lBUnio.Name = "lBUnio";
            this.lBUnio.Size = new System.Drawing.Size(47, 277);
            this.lBUnio.TabIndex = 8;
            this.lBUnio.SelectedIndexChanged += new System.EventHandler(this.lBUnio_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(317, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Unió";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 420);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lBUnio);
            this.Controls.Add(this.btn_szamol);
            this.Controls.Add(this.btn_keszit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lBMetszet);
            this.Controls.Add(this.LBLB);
            this.Controls.Add(this.lBB);
            this.Controls.Add(this.LblA);
            this.Controls.Add(this.lBA);
            this.Name = "Form1";
            this.Text = "Listák";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lBA;
        private System.Windows.Forms.Label LblA;
        private System.Windows.Forms.Label LBLB;
        private System.Windows.Forms.ListBox lBB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lBMetszet;
        private System.Windows.Forms.Button btn_keszit;
        private System.Windows.Forms.Button btn_szamol;
        private System.Windows.Forms.ListBox lBUnio;
        private System.Windows.Forms.Label label2;
    }
}

